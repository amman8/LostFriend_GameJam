using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomFunction : MonoBehaviour
{
    
    void Start()
    {
        
    }

    
    void Update()
    {
        
    }
}
